package com.in28minutes.restfulwebservices;

import static org.mockito.BDDMockito.given;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.restfulwebservices.entities.Product;
import com.in28minutes.restfulwebservices.repositories.ProductRepository;
import com.in28minutes.restfulwebservices.services.ProductDetailService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductDetailServiceTest {


	@MockBean
	private ProductRepository productRepository;

	@Autowired
	private ProductDetailService productDetailServiceImpl;

	@Test
	public void testGetProductDetail(){

		String productId = "1";
		Product productEntiy = new Product();
		populateProduct(productEntiy);
		given(productRepository.getProductDetailById(productId)).willReturn(productEntiy);
		Product product = productDetailServiceImpl.getProductDetail(productId);
		Assert.assertEquals(product.getProductId(), "1");
		Assert.assertEquals(product.getName(), "moto g5 plus");

	}


	private void populateProduct(Product product) {
		product.setProductId("1");
		product.setName("moto g5 plus");
	}



}
