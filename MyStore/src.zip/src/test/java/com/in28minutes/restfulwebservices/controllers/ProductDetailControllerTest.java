package com.in28minutes.restfulwebservices.controllers;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.in28minutes.restfulwebservices.entities.Product;
import com.in28minutes.restfulwebservices.services.ProductDetailService;

@RunWith(SpringRunner.class)
@WebMvcTest(ProductDetailController.class)
public class ProductDetailControllerTest {

	@MockBean
	private ProductDetailService productDetailService;

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testGetProductDetail() throws Exception{

		Product productEntiy = new Product();
		populateProduct(productEntiy);
		given(productDetailService.getProductDetail("1")).willReturn(productEntiy);
		mockMvc.perform(get("/product/1").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("name", is(productEntiy.getName())));
	}

	private void populateProduct(Product product) {
		product.setProductId("1");
		product.setName("moto g5 plus");
	}


}
