package com.in28minutes.restfulwebservices.repositories;

import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.in28minutes.restfulwebservices.entities.Product;

@Repository
public class ProductRepository {

	@Autowired
	private EntityManagerFactory entityManagerFactory;
	
	public Product getProductDetailById(String productId) {

		SessionFactory sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Product product = session.get(Product.class, productId);
		session.getTransaction().commit();
		session.close();
		
		return product;
	}
	
	public Product getProductDetailById1(String productId) {

		SessionFactory sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Product product = session.get(Product.class, productId);
		session.getTransaction().commit();
		session.close();
		
		return product;
	}

}