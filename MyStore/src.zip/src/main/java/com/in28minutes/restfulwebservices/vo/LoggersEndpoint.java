package com.in28minutes.restfulwebservices.vo;

import java.util.Map;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.boot.actuate.logging.LoggersEndpoint.LoggerLevels;
import org.springframework.boot.logging.LogLevel;

@Endpoint(id = "loggers")
public class LoggersEndpoint {

    @ReadOperation
    public Map<String, Object> loggers() {
		return null;
    	
    }

    @ReadOperation
    public LoggerLevels loggerLevels(@Selector String name) {
		return null;
    	
    }

    @WriteOperation
    public void configureLogLevel(@Selector String name, LogLevel configuredLevel) {
    	
    }

}