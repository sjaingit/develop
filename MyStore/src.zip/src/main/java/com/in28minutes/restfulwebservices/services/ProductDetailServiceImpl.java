package com.in28minutes.restfulwebservices.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.in28minutes.restfulwebservices.entities.Product;
import com.in28minutes.restfulwebservices.repositories.ProductRepository;
import com.in28minutes.restfulwebservices.repositories.ProductCrudRepository;

@Service
public class ProductDetailServiceImpl implements ProductDetailService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductCrudRepository productCrudRepository;

	public List<Product> getProductDetailCrud() {
		return (List<Product>)productCrudRepository.findAll();
	}
	
	public Product getProductDetail(String productId) {
		return productRepository.getProductDetailById(productId);
	}

	public Product getProductDetail1(String productId) {
		return productRepository.getProductDetailById1(productId);
	}

}
