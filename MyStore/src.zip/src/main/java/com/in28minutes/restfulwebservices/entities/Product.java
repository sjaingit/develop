package com.in28minutes.restfulwebservices.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dcs_product")
public class Product {
	
	@Id
	private String productId;
	@Column
	private String name;
	@Column
	private String shortDescription;
	@Column
	private String longDescription;
	@Column
	private String productImages;
	@Column
	private String productBrand;
	@Column
	private Double price;
	@Column
	private String vendorId;
	@Column
	private String childSKUs;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	public String getProductImages() {
		return productImages;
	}
	public void setProductImages(String productImages) {
		this.productImages = productImages;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getChildSKUs() {
		return childSKUs;
	}
	public void setChildSKUs(String childSKUs) {
		this.childSKUs = childSKUs;
	}
	
}
