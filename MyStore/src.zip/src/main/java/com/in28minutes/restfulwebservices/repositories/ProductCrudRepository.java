package com.in28minutes.restfulwebservices.repositories;

import org.springframework.data.repository.CrudRepository;

import com.in28minutes.restfulwebservices.entities.Product;

public interface ProductCrudRepository extends CrudRepository<Product, String> {
	

}
