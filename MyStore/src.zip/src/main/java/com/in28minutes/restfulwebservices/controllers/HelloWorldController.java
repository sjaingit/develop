/*package com.in28minutes.restfulwebservices.controllers;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.in28minutes.restfulwebservices.exception.UserNotFoundException;
import com.in28minutes.restfulwebservices.vo.User;

@RestController
public class HelloWorldController {
	
	@RequestMapping(method=RequestMethod.GET, path="/hello-world")
	public Object helloworld(){
		return  new User(1, "abc", new Date());
	}
	
	@RequestMapping(path = "/hello-world-bean")
	public ResponseEntity<User> helloWorldBean() {
		
		User u = new User(1, "abc", new Date());
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
						.path("q").buildAndExpand().toUri();
		return ResponseEntity(u).created(location).build();
		
		return new ResponseEntity<User>(u,HttpStatus.CREATED);
	}
	
	@RequestMapping(path = "/hateoas")
	public Resource<User> hateoas() {
		
		User u = new User(1, "abc", new Date());
		
		Resource<User> resource = new Resource<>(u);
		
		ControllerLinkBuilder lnk = ControllerLinkBuilder.linkTo(
				ControllerLinkBuilder.methodOn(this.getClass()).helloWorldBean());
				
		resource.add(lnk.withRel("hello-world-bean"));
		
		return resource;
	}
	
	@RequestMapping(path = "/notfound")
	public User notfound() {
		
		User u = new User(1, "abc", new Date());
		if(u.getId()==1){
		throw new UserNotFoundException("not found test");
		}
		return u;
	}
	
	@PostMapping(path = "/validation")
	public Object validation(@Valid @RequestBody User user) {
		
		return "checking";
	}
}
*/