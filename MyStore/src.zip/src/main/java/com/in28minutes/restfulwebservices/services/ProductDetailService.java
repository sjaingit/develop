package com.in28minutes.restfulwebservices.services;

import java.util.List;

import com.in28minutes.restfulwebservices.entities.Product;

public interface ProductDetailService {
	
	public Product getProductDetail(String productId);
	public Product getProductDetail1(String productId);
	public List<Product> getProductDetailCrud();

}
