package com.in28minutes.restfulwebservices.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.in28minutes.restfulwebservices.entities.Product;
import com.in28minutes.restfulwebservices.services.ProductDetailService;

@Controller
public class ProductDetailController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductDetailController.class);
	
	@Autowired
	private ProductDetailService productDetailService;
	
	@RequestMapping(value="/product/{productId}",method=RequestMethod.GET)
	public @ResponseBody Product getProductDetail(@PathVariable String productId){
		
		LOGGER.debug("Start getProductDetail");
		Product product = productDetailService.getProductDetail(productId);
		LOGGER.debug("End getProductDetail");
		return product;
		
	}
	
	@RequestMapping(value="/product1/{productId}",method=RequestMethod.GET)
	public @ResponseBody Product getProductDetail1(@PathVariable String productId){
		
		Product product = productDetailService.getProductDetail1(productId);
		return product;
		
	}
	
	@RequestMapping(value="/product",method=RequestMethod.GET)
	public @ResponseBody List<Product> getAllProductsDetail(){
		
		List<Product> product = productDetailService.getProductDetailCrud();
		return product;
	}

}
